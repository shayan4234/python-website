import tkinter
import random
import csv
import pandas
# -*- coding: utf-8 -*-
BACKGROUND_COLOR = "#B1DDC6"
file_path = 'data/ENG/eng_3000_Oxford_A1.txt'
delimiter = '|'

df = pandas.read_csv(file_path, sep=delimiter)
value = df.columns
language_1 = value[0]
language_2 = value[1]

count_all = 0
count_good = 0
word_count = '500'  # all-vsetky slovicka, alebo cislo mensie ako pocet slovicok v subore, vzdy je to str aj ked je to cislo

data_list = []
with open(file_path, 'r', encoding="utf-8") as csv_file:
    csv_reader = csv.DictReader(csv_file, delimiter=delimiter)
    for row in csv_reader:
        data_list.append(row)

data_list_selected = []
# random.shuffle(data_list)
if word_count == 'all':
    word_count_selected = len(data_list)
else:
    word_count_selected = int(word_count)
chosen_items = random.sample(data_list, word_count_selected)
data_list_selected.extend(chosen_items)
data_list_first_count = len(data_list_selected)
data_list_actual_count = len(data_list_selected)

# Creating a new window and configurations
window = tkinter.Tk()
window.title("Flashy")
window.minsize(width=500, height=500)
window.configure(bg=BACKGROUND_COLOR, pady=50, padx=50)

# Images
my_image_right = tkinter.PhotoImage(file="images/right.png")
my_image_wrong = tkinter.PhotoImage(file="images/wrong.png")

foreign_word = random.choice(data_list_selected)

# Canvas
canvas_layout = 0
img_card_front = tkinter.PhotoImage(file="images/card_front.png")
canvas = tkinter.Canvas(window, width=800, height=550, bg=BACKGROUND_COLOR, highlightthickness=0)
canvas.grid(column=0, row=0, columnspan=3)
canvas_image = canvas.create_image(0, 0, anchor=tkinter.NW, image=img_card_front)
text_1 = canvas.create_text(400, 150, text=language_1, font=("Arial", 40, "italic"), fill="black")
text_2 = canvas.create_text(400, 263, text=foreign_word[language_1], font=("Arial", 60, "bold"), fill="black")


def change_word():
    global text_2
    global foreign_word
    foreign_word = random.choice(data_list_selected)
    canvas.delete(text_2)
    text_2 = canvas.create_text(400, 263, text=foreign_word[language_1], font=("Arial", 60, "bold"), fill="black")


# Buttons
def action_button_right():
    global canvas_layout
    global count_all
    global count_good
    count_all += 1
    # print(count_all)
    count_good += 1
    label_uspesnost.config(text=f'Stav: {count_good}/{count_all} {round((count_good/count_all*100),2)}%')
    if canvas_layout == 1:
        pass
    else:
        data_list_selected.remove(foreign_word)
        data_list_actual_count = len(data_list_selected)
        label_spolu.config(text=f'Stav: {data_list_actual_count}/{data_list_first_count}')
        change_word()

def action_button_wrong():
    global canvas_layout
    global count_all
    count_all += 1
    label_uspesnost.config(text=f'Stav: {count_good}/{count_all} {round((count_good/count_all*100),2)}%')
    if canvas_layout == 1:
        pass
    else:
        change_word()

def action_button_flip():
    global canvas_layout
    global canvas
    global canvas_image
    global img_card_back
    global img_card_front
    if canvas_layout == 0:
        img_card_back = tkinter.PhotoImage(file="images/card_back.png")
        canvas.itemconfig(canvas_image, image=img_card_back)
        canvas.itemconfig(text_1, text=language_2)
        canvas.itemconfig(text_2, text=foreign_word[language_2])
        canvas_layout = 1
    elif canvas_layout == 1:
        img_card_front = tkinter.PhotoImage(file="images/card_front.png")
        canvas.itemconfig(canvas_image, image=img_card_front)
        canvas.itemconfig(text_1, text=language_1)
        canvas.itemconfig(text_2, text=foreign_word[language_1])
        canvas_layout = 0

button_right = tkinter.Button(image=my_image_right, highlightthickness=0, command=action_button_right)
button_right.grid(column=0, row=2)
button_wrong = tkinter.Button(image=my_image_wrong, highlightthickness=0, command=action_button_wrong)
button_wrong.grid(column=2, row=2)
button_flip = tkinter.Button(text="Flip", height=5, width=10, highlightthickness=0, command=action_button_flip)
button_flip.grid(column=1, row=2)

# Labels
label_spolu = tkinter.Label(text=f'Stav: {data_list_actual_count}/{data_list_first_count}')
label_spolu.grid(column=3, row=0, sticky='N')
label_uspesnost = tkinter.Label(text=f'Úspesnosť: {count_good}/{count_all}')
label_uspesnost.grid(column=3, row=0, sticky='S')


window.mainloop()
